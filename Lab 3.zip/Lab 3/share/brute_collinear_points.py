from line_segment import LineSegment
from point import Point
from itertools import combinations


class BruteCollinearPoints:
    def __init__(self, points: list[Point]):
        # Check for corner cases
        if points is None:
            raise ValueError("Input cannot be None")
        
        # points.copy() to avoid modifying the input
        self._points = points.copy()
        
        # Check for null points and duplicates
        for i, p in enumerate(self._points):
            if p is None:
                raise ValueError("Points cannot be None")
            
            for j in range(i + 1, len(self._points)):
                if self._points[i].equals(self._points[j]):
                    raise ValueError("Duplicate points are not allowed")
        
         # Find all collinear segments
        self._segments = []
        
        # Use combinations to generate all sets of 4 points
        for four_points in combinations(self._points, 4):
            p, q, r, s = four_points
            
            # Calculate slopes
            slope_pq = p.slope_to(q)
            slope_pr = p.slope_to(r)
            slope_ps = p.slope_to(s)
            
            # Check if points are collinear
            if slope_pq == slope_pr == slope_ps:
                # Find the endpoints of the segment
                points = list(four_points)
                
                # Find min and max points
                min_point = points[0]
                max_point = points[0]
                
                for point in points[1:]:
                    # Compare x coordinates first
                    if point.x() < min_point.x() or (point.x() == min_point.x() and point.y() < min_point.y()):
                        min_point = point
                    if point.x() > max_point.x() or (point.x() == max_point.x() and point.y() > max_point.y()):
                        max_point = point
                
                # Create a line segment from the extremes
                segment = LineSegment(min_point, max_point)
                self._segments.append(segment)

    def number_of_segments(self) -> int:
       return len(self._segments)

    def segments(self) -> list[LineSegment]:
        # Return a copy to prevent modification
        return self._segments.copy()
    