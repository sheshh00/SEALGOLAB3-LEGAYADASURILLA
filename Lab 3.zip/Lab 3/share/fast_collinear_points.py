from line_segment import LineSegment
from point import Point


class FastCollinearPoints:
    def __init__(self, points: list[Point]):
        if points is None or any(p is None for p in points):
            raise ValueError("Points cannot be None.")
        if len(set(points)) != len(points):
            raise ValueError("Points cannot have duplicates.")
        self.points = points  
       
    def number_of_segments(self) -> int:
        return len(self.segments_list)

    def segments(self) -> list[LineSegment]:
        return self.segments_list